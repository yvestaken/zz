export default function scrollTo(elementId) {
  let elementPos = document.getElementById(elementId).offsetTop;
  window.scrollTo({
    top: elementPos,
    behavior: "smooth",
  });
}
