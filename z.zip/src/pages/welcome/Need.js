export default function Need() {
  return (
    <div
      className="pt-10 w-full h-auto bg-background dark:bg-white"
      id="features"
    >
      <h2 className="text-[30px] mr-16 hidden md:flex lg:hidden justify-end items-center font-bold text-white dark:text-background">
        EVERYTHING YOU NEED!
      </h2>
      <div className="relative sm:mx-6 md:mx-16 lg:mx-40 xl:mx-auto flex flex-col md:flex-row justify-between xl:max-w-screen-xl">
        <img
          className="z-20 object-contain h-[450px] md:w-[350px] md:h-[700px] lg:w-[400px] lg:h-[790px]"
          src="static/img/TransparentMirror.png"
          alt="TransparentMirror"
        />
        <div className="absolute z-10 bottom-32 lg:bottom-24 md:w-[350px] md:h-[350px] lg:w-[468px] lg:h-[468px] border-3 border-primary -rotate-[22deg]"></div>
        <div className="flex flex-col">
          <h2 className="text-[30px] flex mt-10 md:hidden lg:flex lg:mt-0 lg:text-[50px] font-bold text-white dark:text-background">
            EVERYTHING YOU NEED!
          </h2>
          <div className="my-10 md:my-auto flex flex-col gap-y-8 lg:gap-y-10">
            <div className="flex flex-row items-center justify-between space-x-10 md:space-x-12">
              <div className="w-12 h-12 lg:w-24 lg:h-24 rounded-full flex items-center justify-center bg-white dark:bg-primary">
                <img
                  className="w-6 h-6 lg:w-14 lg:h-14"
                  src="static/img/Height.png"
                  alt="Height"
                />
              </div>
              <div className="w-full md:w-[280px] lg:w-[480px] flex flex-col">
                <h3 className="font-bold text-[20px] mb-4 text-white dark:text-background">
                  Body Measurement Tracking
                </h3>
                <p className="text-white dark:text-background">
                Begin provides a highly accurate replica of the user’s body
                via scanning and image processing. We make sure that the user's body tracker is not just close but a perfect replica of the user.
                </p>
              </div>
            </div>

            <div className="flex flex-row items-center justify-between space-x-10 md:space-x-12">
              <div className="w-12 h-12 lg:w-24 lg:h-24 rounded-full flex items-center justify-center bg-white dark:bg-primary">
                <img
                  className="w-6 h-6 lg:w-14 lg:h-14"
                  src="static/img/Closet.png"
                  alt="Closet"
                />
              </div>
              <div className="w-full md:w-[280px] lg:w-[480px] flex flex-col">
                <h3 className="font-bold text-[20px] mb-4 text-white dark:text-background">
                  In-Home Trial of Clothes & Closet
                </h3>
                <p className="text-white dark:text-background">
                Begin helps you to try your clothes at your home by showcasing them on your metahuman. Your avatar lets you understand your clothing theme in different ambience. 
                </p>
              </div>
            </div>

            <div className="flex flex-row items-center justify-between space-x-10 md:space-x-12">
              <div className="w-12 h-12 lg:w-24 lg:h-24 rounded-full flex items-center justify-center bg-white dark:bg-primary">
                <img
                  className="w-6 h-6 lg:w-14 lg:h-14"
                  src="static/img/Shirt.png"
                  alt="Shirt"
                />
              </div>
              <div className="w-full md:w-[280px] lg:w-[480px] flex flex-col">
                <h3 className="font-bold text-[20px] mb-4 text-white dark:text-background">
                  Recommendation of Clothes Using AI
                </h3>
                <p className="text-white dark:text-background">
                Begin’s algorithm helps user to select what to buy depending upon the recommendation of various users. We make sure that your clothing game is up-to-the-mark. 
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
