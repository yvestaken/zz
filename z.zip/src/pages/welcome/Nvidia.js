export default function Nvidia() {
  return (
    <div className="w-full bg-background">
      <div className="relative w-full h-60 md:h-80 lg:h-[400px] xl:h-[480px] bg-[url('/public/static/img/nvideosec.png')] bg-center bg-cover bg-no-repeat">
        <div className="absolute top-16 left-6 md:top-24 md:left-16 lg:top-32 lg:left-40 xl:top-40 xl:left-80 w-[200px] md:w-[450px] lg:w-[600px] xl:w-[750px] text-[20px] md:text-[30px] lg:text-[40px] xl:text-[50px] text-white">
          Using&nbsp;<span className="text-[#91E227]">nvidia</span> cloud to run
          and produce realistic results.
        </div>
      </div>
    </div>
  );
}
