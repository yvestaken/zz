// core components
import { PrimaryButton } from "../../components/core/button";

export default function Store() {
  return (
    <div className="w-full px-6 md:px-16 lg:px-40 xl:px-52 bg-background dark:bg-white" id="store">
      <div className="xl:mx-auto xl:max-w-screen-xl">
        <div className="relative !w-full h-[calc(375px)] md:h-[calc(635px)]  lg:h-[calc(800px)] xl:h-[calc(1080px)] bg-[url('/public/static/img/CharacterAnim.gif')] bg-center bg-contain bg-no-repeat">
          <div className="absolute w-[200px] md:w-[400px] xl:w-[640px] right-[60px] top-10 md:top-20 lg:top-40">
            <p className="text-[9px] md:text-[18px] text-white mb-8 dark:text-black">
            Begin algorithm designed by experts in fields expanding from technology to fashion design will provide the user with an incredibly vast selection of garments that are specifically chosen for the piece the user has provided initially to the mirror.
            </p>
            <PrimaryButton>Learn More</PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}
