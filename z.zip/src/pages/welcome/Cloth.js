import "./style.scss";
// module
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function NextArrow(props) {
  const { onClick, currentSlide } = props;
  return (
    <button
      className={
        `absolute z-10 -right-12 top-20 h-15 cursor-pointer transition-all duration-1000 visible opacity-100` +
        (currentSlide === 1 ? "invisible opacity-0" : "")
      }
      onClick={onClick}
    >
      <svg
        width="9"
        height="15"
        viewBox="0 0 9 15"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M1.27717 14.9981C0.979279 14.9986 0.69059 14.9116 0.461216 14.7522C0.332119 14.6624 0.225406 14.5522 0.147187 14.4278C0.0689677 14.3035 0.0207803 14.1674 0.00538454 14.0273C-0.0100113 13.8873 0.00768725 13.7461 0.057466 13.6118C0.107245 13.4776 0.188125 13.3528 0.295476 13.2448L6.00713 7.51466L0.499465 1.77382C0.393562 1.66447 0.314476 1.53865 0.266753 1.40358C0.219031 1.26852 0.203612 1.12688 0.221384 0.986799C0.239155 0.846722 0.289765 0.710971 0.370307 0.587349C0.450849 0.463727 0.559734 0.354671 0.690703 0.266449C0.822614 0.169126 0.977091 0.0957163 1.14444 0.0508276C1.31179 0.0059389 1.4884 -0.00945949 1.66318 0.00559807C1.83796 0.0206556 2.00715 0.0658444 2.16012 0.138329C2.31309 0.210813 2.44654 0.309027 2.55209 0.426808L8.70997 6.84116C8.89749 7.03244 9 7.27239 9 7.52001C9 7.76763 8.89749 8.00757 8.70997 8.19886L2.33535 14.6132C2.20746 14.7426 2.04499 14.8448 1.86113 14.9117C1.67728 14.9786 1.47721 15.0082 1.27717 14.9981Z"
          className="fill-white dark:fill-black"
        />
      </svg>
    </button>
  );
}

function PrevArrow(props) {
  const { onClick, currentSlide } = props;
  return (
    <button
      className={
        "absolute z-10 !-right-12 top-40 cursor-pointer transition-all duration-1000 visible opacity-100" +
        (currentSlide === 0 ? "invisible opacity-0" : "")
      }
      onClick={onClick}
    >
      <svg
        width="9"
        height="15"
        viewBox="0 0 9 15"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M7.72283 14.9981C8.02072 14.9986 8.30941 14.9116 8.53878 14.7522C8.66788 14.6624 8.77459 14.5522 8.85281 14.4278C8.93103 14.3035 8.97922 14.1674 8.99462 14.0273C9.01001 13.8873 8.99231 13.7461 8.94253 13.6118C8.89276 13.4776 8.81188 13.3528 8.70452 13.2448L2.99287 7.51466L8.50054 1.77382C8.60644 1.66447 8.68552 1.53865 8.73325 1.40358C8.78097 1.26852 8.79639 1.12688 8.77862 0.986799C8.76084 0.846722 8.71023 0.710971 8.62969 0.587349C8.54915 0.463727 8.44027 0.354671 8.3093 0.266449C8.17739 0.169126 8.02291 0.0957163 7.85556 0.0508276C7.68821 0.0059389 7.5116 -0.00945949 7.33682 0.00559807C7.16204 0.0206556 6.99285 0.0658444 6.83988 0.138329C6.68691 0.210813 6.55346 0.309027 6.44791 0.426808L0.290029 6.84116C0.102511 7.03244 -1.2532e-07 7.27239 -1.2532e-07 7.52001C-1.2532e-07 7.76763 0.102511 8.00757 0.290029 8.19886L6.66465 14.6132C6.79254 14.7426 6.95501 14.8448 7.13887 14.9117C7.32272 14.9786 7.52279 15.0082 7.72283 14.9981Z"
          className="fill-white dark:fill-black"
        />
      </svg>
    </button>
  );
}

export default function Cloth() {
  const settings = {
    infinite: false,
    className: "center",
    centerPadding: "0px",
    slidesToShow: 1,
    speed: 1000,
    prevArrow: <PrevArrow />,
    nextArrow: <NextArrow />,
  };
  return (
    <div className="px-6 py-20 md:px-16 lg:pt-20 lg:pb-32 lg:px-40 bg-background dark:bg-gray-100">
      <div className="relative xl:mx-auto xl:max-w-screen-xl">
        <div className="flex flex-col bg-secondary pt-52 pb-20 lg:pt-24 lg:pb-32 lg:pl-28">
          <h1 className="z-10 text-[50px] font-bold text-white">
            3D clothing simulation on <br /> user-designed metahuman
          </h1>
          <div className="z-10 mt-8 mb-12 flex flex-row">
            <div className="h-1 bg-primary w-80"></div>
            <div className="h-1 bg-[#515151] w-44"></div>
          </div>
          <p className="z-10 mb-8 w-full md:w-[400px] lg:w-[682px] text-white">
          Begin simulate clothing on a user-designed metahuman to allow the user to see closely how the outfit will look on them without a need to test-run any garment physically. By default, a normal metal surface character will be provided, however an intricate yet user-friendly customization process will be provided to the user to ensure accuracy and satisfaction. 
          </p>
          <div className="w-56 cursor-pointer group transition ease-in-out duration-500 flex flex-row space-x-1 px-6 py-3 bg-white hover:!bg-black text-background hover:text-white">
            <p className="font-bold">DISCOVER MORE</p>
            <div className="group-hover:ml-5 transition-all">
              <svg
                width="26"
                height="26"
                viewBox="0 0 26 26"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M10.8333 20.5834C10.5802 20.5838 10.3349 20.4957 10.14 20.3342C10.0303 20.2432 9.93964 20.1315 9.87318 20.0055C9.80671 19.8795 9.76577 19.7415 9.75268 19.5997C9.7396 19.4578 9.75464 19.3147 9.79694 19.1786C9.83924 19.0425 9.90796 18.9162 9.99918 18.8067L14.8525 13L10.1725 7.18252C10.0825 7.07171 10.0153 6.9442 9.97477 6.80733C9.93422 6.67047 9.92112 6.52693 9.93622 6.38499C9.95132 6.24304 9.99433 6.10548 10.0628 5.9802C10.1312 5.85493 10.2237 5.74442 10.335 5.65502C10.4471 5.55639 10.5784 5.482 10.7206 5.43652C10.8628 5.39103 11.0128 5.37542 11.1614 5.39068C11.3099 5.40594 11.4536 5.45173 11.5836 5.52519C11.7136 5.59864 11.827 5.69816 11.9167 5.81752L17.1492 12.3175C17.3085 12.5114 17.3956 12.7545 17.3956 13.0054C17.3956 13.2564 17.3085 13.4995 17.1492 13.6934L11.7325 20.1934C11.6238 20.3245 11.4858 20.4281 11.3296 20.4958C11.1733 20.5636 11.0033 20.5936 10.8333 20.5834Z"
                  fill="#1EE1B3"
                />
              </svg>
            </div>
          </div>
        </div>

        <div className="absolute -top-20 right-0 h-[780px] w-[520px]">
          <Slider {...settings}>
            <img src="static/img/v4.png" alt="v4" />
            <img src="static/img/v5.png" alt="v5" />
            {/* <div className="relative w-full h-full">
              <img src="static/img/v4.png" alt="v4" />
            </div> */}
          </Slider>
        </div>
      </div>
    </div>
  );
}
