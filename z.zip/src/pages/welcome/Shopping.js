export default function Shopping() {
  return (
    <div className="py-28 flex flex-col items-center justify-center space-y-12 bg-[#0C0C11] dark:bg-[#2A2320]">
      <p className="text-[40px] font-semibold text-white text-center">
        Enhance your shopping experience <br />
        with elevated expertise and efficient time constraints.
      </p>
      <div className="bg-primary w-20 border-3 border-primary rounded"></div>
      <div className="w-20 h-20 overflow-hidden">
        <svg
          className="group cursor-pointer  hover:stroke-primary transition"
          width="77"
          height="77"
          viewBox="0 0 77 77"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            x="1"
            y="1"
            width="75"
            height="75"
            strokeWidth="2"
            className="stroke-white group-hover:stroke-primary"
          />
          <path
            className="group-hover:scale-150 group-hover:stroke-primary group-hover:fill-primary origin-center transition"
            d="M35.6151 50.5235C35.1191 50.5206 34.6293 50.413 34.1778 50.2076C33.6895 49.9924 33.2735 49.6412 32.9794 49.1959C32.6854 48.7506 32.5257 48.23 32.5195 47.6964V34.398C32.5257 33.8644 32.6854 33.3439 32.9794 32.8986C33.2735 32.4533 33.6895 32.102 34.1778 31.8868C34.7397 31.6214 35.3648 31.5192 35.9819 31.5918C36.599 31.6644 37.1833 31.9089 37.6683 32.2975L45.7231 38.9466C46.039 39.1981 46.2941 39.5176 46.4694 39.8813C46.6447 40.2449 46.7358 40.6435 46.7358 41.0472C46.7358 41.451 46.6447 41.8495 46.4694 42.2132C46.2941 42.5769 46.039 42.8963 45.7231 43.1478L37.6683 49.797C37.0876 50.2679 36.3626 50.5244 35.6151 50.5235Z"
            fill="white"
          />
        </svg>
      </div>
    </div>
  );
}
