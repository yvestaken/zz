// core componets
import { PrimaryButton } from "../../components/core/button";

const NextArrowIcon = () => {
  return (
    <svg
      width="27"
      height="27"
      viewBox="0 0 27 27"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M10.9309 20.7686C10.6755 20.7691 10.428 20.6801 10.2313 20.5172C10.1206 20.4254 10.0291 20.3127 9.96207 20.1855C9.89501 20.0583 9.85369 19.9192 9.84049 19.776C9.82729 19.6328 9.84247 19.4885 9.88515 19.3512C9.92783 19.2139 9.99717 19.0864 10.0892 18.9759L14.9863 13.1169L10.2641 7.24705C10.1733 7.13524 10.1055 7.00658 10.0646 6.86848C10.0237 6.73038 10.0104 6.58556 10.0257 6.44233C10.0409 6.29911 10.0843 6.1603 10.1534 6.0339C10.2224 5.9075 10.3158 5.79599 10.4281 5.70579C10.5412 5.60628 10.6736 5.53122 10.8171 5.48532C10.9606 5.43942 11.112 5.42368 11.2619 5.43907C11.4117 5.45447 11.5568 5.50067 11.6879 5.57479C11.8191 5.6489 11.9335 5.74932 12.024 5.86975L17.3036 12.4283C17.4644 12.6239 17.5523 12.8692 17.5523 13.1224C17.5523 13.3756 17.4644 13.6209 17.3036 13.8165L11.8382 20.3751C11.7285 20.5073 11.5892 20.6119 11.4316 20.6803C11.2739 20.7487 11.1024 20.7789 10.9309 20.7686Z"
        fill="#1EE1B3"
      />
    </svg>
  );
};

export default function Useful() {
  return (
    <div
      className="w-full pt-36 pb-20 flex flex-col items-center justify-center bg-background dark:bg-[#3A322F]"
      id="why-begin"
    >
      <p className="text-[32px] font-semibold text-center text-white">
        How it is useful for user and companies
      </p>
      <div className="mt-7 mb-12 border-3 border-primary w-20 rounded"></div>
      <div className="mb-[70px] grid grid-rows-3 md:grid-rows-1 md:grid-cols-3 gap-6 lg:gap-20">
        <div className="group cursor-pointer bg-secondary p-8 flex flex-col space-y-6">
          <div className="flex flex-row items-center gap-x-2">
            <h3 className="font-extrabold text-[20px] text-white">
              Our Commitment
            </h3>
            <div className="ml-0 group-hover:ml-10 transition-all">
              <NextArrowIcon />
            </div>
          </div>
          <p className="text-white text-[15px] leading-5 w-60   ">
            Begin is helping brands to increase sales by enhancing user experience through metahuman
          </p>
        </div>
        <div className="group cursor-pointer bg-secondary p-8 flex flex-col space-y-6">
          <div className="flex flex-row items-center gap-x-2">
            <h3 className="font-extrabold text-[20px] text-white">
              Fit means Fit
            </h3>
            <div className="ml-0 group-hover:ml-10 transition-all">
              <NextArrowIcon />
            </div>
          </div>
          <p className="text-white text-[15px] leading-5 w-60   ">
          Begin is attempting to resolve the sizing problem of different brands
          </p>
        </div>
        <div className="group cursor-pointer bg-secondary p-8 flex flex-col space-y-6">
          <div className="flex flex-row items-center gap-x-2">
            <h3 className="font-extrabold text-[20px] text-white">
              No Need to Hop Around
            </h3>
            <div className="ml-0 group-hover:ml-10 transition-all">
              <NextArrowIcon />
            </div>
          </div>
          <p className="text-white text-[15px] leading-5 w-60   ">
          Through begin users can overcome the issue of cross-brand trials with ease.
          </p>
        </div>
      </div>
      <PrimaryButton>Learn More</PrimaryButton>
    </div>
  );
}
