import React from "react";

// module
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

// component
import Accordion from "../../components/accordian";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
    slidesToSlide: 3, // optional, default to 1.
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
    slidesToSlide: 2, // optional, default to 1.
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
    slidesToSlide: 1, // optional, default to 1.
  },
};

export default function Feature() {
  return (
    <div
      className="p-6 md:px-16 lg:px-40 bg-background dark:bg-white"
      id="specs"
    >
      <div className="flex flex-col items-center justify-center xl:mx-auto xl:max-w-screen-xl">
        <h2 className="text-[32px] font-semibold text-white">
          Sleek Built
        </h2>
        <div className="my-[58px] border-3 border-primary w-20 rounded"></div>
        <div className="w-full flex flex-col justify-center items-center text-primary">
          <Accordion title={"MATERIALS"} />
          <Accordion title={"CAMERA"} />
          <Accordion title={"SURROUND SOUND"} />
          <Accordion title={"LED DISPLAY"} />
        </div>
        <div>
          <h2> Single Item</h2>
        </div>

        <Carousel
          responsive={responsive}
          ssr={true} // means to render carousel on server-side.
        >
          <div>Item 1</div>
          <div>Item 2</div>
          <div>Item 3</div>
          <div>Item 4</div>
        </Carousel>
        <h2 className="md:w-[600px] lg:w-[720px] text-[32px] font-semibold text-white mt-[58px] text-center">
          Cross store shopping in real time and cloth simulation on your own
          character!
        </h2>
        <div className="my-[58px] border-3 border-primary w-20 rounded"></div>
      </div>
    </div>
  );
}
