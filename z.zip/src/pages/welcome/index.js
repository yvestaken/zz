import React from "react";
// pages
import Hero from "./Hero";
import About from "./About";
import Need from "./Need";
import Shopping from "./Shopping";
import Useful from "./Useful";
import Cloth from "./Cloth";
import Feature from "./Feature";
import Store from "./Store";
import Nvidia from "./Nvidia";
import Zozosuit from "./Zozosuit";

export default function Welcome() {
  return (
    <React.Fragment>
      <Hero />
      <About />
      <Need />
      <Shopping />
      <Useful />
      <Cloth />
      <Feature />
      <Store />
      <Nvidia />
      <Zozosuit />
    </React.Fragment>
  );
}
