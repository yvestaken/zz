import React from "react";

export default function Hero() {
  return (
    <div>
      <div className="relative z-10 !w-full h-[calc(100vh)] bg-[url('/public/static/img/header.png')] bg-center bg-cover bg-no-repeat">
        <div className="absolute top-1/2 -translate-y-1/2 right-6 md:right-16 lg:right-40 xl:right-52">
          <div className=" flex flex-col items-end">
            <div
              data-aos="fade-up"
              data-aos-duration="800"
              data-aos-easing="ease-in-out"
            >
              <div className="text-[14px] font-bold text-primary">Try Clothes Like You've Never Done Before</div>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-easing="ease-in-out"
            >
              <div className="text-[130px] font-bold text-white m-0 leading-[130px]">
                BEGIN
              </div>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1800"
              data-aos-easing="ease-in-out"
            >
              <div className="w-20 h-0.5 bg-primary"></div>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="1800"
              data-aos-easing="ease-in-out"
            >
              <div className="flex flex-row items-center justify-between">
              <div className="w-3 h-3"></div>
              </div>
              <div className="text-[12px] text-white w-[300px] margin-left: auto;margin-right: 0;">
                Begin provides the user with the resources of complex fashion and style that many find to be difficult to obtain.
              </div>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="2000"
              data-aos-easing="ease-in-out"
            >
              <div className="flex flex-row gap-8 mt-8 rounded-sm">
              <div contenteditable="true">
                <div className="text-[#6C6C6C] border-2 border-black px-14 py-4 cursor-pointer">
                  ENTER YOUR EMAIL
                </div>
              </div>
                <div className="text-white bg-background px-10 py-4 cursor-pointer rounded-sm hover:bg-primary transition-all duration-500">
                  GET STARTED
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
