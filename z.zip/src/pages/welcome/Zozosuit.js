export default function Zozosuit() {
  return (
    <div className="relative flex flex-col bg-background">
      <div className=" w-full px-6 md:px-16 lg:px-40 xl:px-52 pt-20">
        <div className="flex flex-row justify-between items-center xl:mx-auto xl:max-w-screen-xl">
          <img
            className="w-[180px] md:w-[300px] lg:w-[400px] xl:w-[500px] z-10"
            src="static/img/zozosuit2.png"
            alt="zozosuit2"
          />
          <p className="w-full md:w-[400px] lg:w-[696px] text-white text-[9px] md:text-[13px] lg:text-[20px]">
            In collaboration with ZOZOSUIT, our mirror will also provide a
            highly accurate replica of the user’s body via scanning and image
            processing. Through this, we will also be able to provide motion
            tracking for the user-customized metahuman in real time, making the
            experience incredibly realistic provided the mirror will be touch
            screen and interactive.
          </p>
        </div>
      </div>
      <div className="absolute top-[200px] md:top-[292px] lg:top-[368px] xl:top-[444px] w-full inline-flex flex-row items-center pr-40 bg-background">
        <div className="w-full h-0.5 bg-[#545454]"></div>
        <p className="ml-14 text-[24px] text-white hover:ml-[37px] hover:tracking-widest transition duration-1000 origin-center">ZOZOSUIT</p>
      </div>
    </div>
  );
}
