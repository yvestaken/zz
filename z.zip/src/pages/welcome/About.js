// module
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

// core components
import { PrimaryButton } from "../../components/core/button";

function TeamNextArrow(props) {
  const { onClick } = props;
  return (
    <div
      className="absolute z-10 right-0 top-0 cursor-pointer w-10 h-10 bg-[url('/public/static/img/next-arrow-default.svg')] hover:bg-[url('/public/static/img/next-arrow-variant.svg')]"
      onClick={onClick}
    >
    </div>
  );
}

function TeamPrevArrow(props) {
  const { onClick } = props;
  return (
    <div
      className="absolute z-10 right-10 top-0 cursor-pointer w-10 h-10 bg-[url('/public/static/img/prev-arrow-default.svg')] hover:bg-[url('/public/static/img/prev-arrow-variant.svg')]"
      onClick={onClick}
    ></div>
  );
}

export default function About() {
  const settings = {
    className: "center",
    infinite: true,
    centerPadding: "0px",
    slidesToShow: 1,
    speed: 500,
    nextArrow: <TeamNextArrow />,
    prevArrow: <TeamPrevArrow />,
  };
  return (
    <div className="relative bg-background w-full h-auto py-20 dark:bg-gray-100" id="about">
      <div className="hidden md:flex absolute text-[250px] font-bold -top-48 md:left-10 lg:left-48 opacity-10 text-[#252528]">
        BEGIN
      </div>
      <div className="w-full flex items-center justify-center gap-2 md:gap-10 lg:gap-20">
        <img
          src="static/img/logos/UnrealEngineLogo.png"
          alt="UnrealEngineLogo"
        />
        <img src="static/img/logos/NvidiaLogo.png" alt="NvidiaLogo" />
        <img src="static/img/logos/BrowzwearLogo.png" alt="BrowzwearLogo" />
        <img src="static/img/logos/CloLogo.png" alt="CloLogo" />
      </div>
      <div className="flex flex-col md:flex md:flex-row md:items-center md:justify-between sm:mt-20 md:mt-40 sm:mx-6 md:mx-16 lg:mx-40 xl:mx-auto xl:max-w-screen-xl">
        <div className="md:w-[300px] lg:w-[500px] xl:w-[732px] flex flex-col justify-start">
          <div className="text-primary font-bold text-[32px] dark:text-background">
            Introducing
          </div>
          <div className="flex flex-row pb-16">
            <div className="w-[60px] h-0.5 bg-primary"></div>
            <div className="w-[35px] h-0.5 bg-[#515151]"></div>
          </div>
          <p className="text-white pb-10 dark:text-background">
            The newly designed BEGIN will completely alter the reality of
            fashion, individually and commercially as we know it. A major
            attribute of this mirror is to provide the user with the resources
            of complex fashion and style that many find difficult to obtain. Its
            main focus will be the user’s stylistic preferences and will then
            provide the user with an outfit which meets their own style while
            simultaneously using expert knowledge to ensure an outfit of pride.
            Because self-presentation is such a prominent element of judgement,
            all kinds of people are vehemently dressing in all kinds of ways to
            fit certain descriptions, norms, and anything that will allow their
            confidence to break through the cracks of self-doubt.
          </p>
          <PrimaryButton>Learn More</PrimaryButton>
        </div>
        
        <div className="relative mt-20 md:my-auto w-[300px] md:w-[350px] lg:w-[430px] h-[350px] md:h-[400px] lg:h-[532px]">
          <Slider {...settings}>
            <div className="relative w-full h-full overflow-hidden [&>div]:hover:bottom-0">
              <img
                src="static/img/collection1.png"
                alt="UnrealEngineLogo"
                className="hover:scale-125 transition w-full h-full"
              />
              <div className="ease-in-out duration-300 -bottom-40 absolute bg-background opacity-80 px-12 py-8">
                <p className="text-primary font-bold text-[23px]">
                  BEGIN
                </p>
                <p className="text-white text-[20px]">
                Try Clothes Like You've Never Done Before
                </p>
              </div>
            </div>
            <div className="relative w-full h-full overflow-hidden [&>div]:hover:bottom-0">
              <img
                src="static/img/collection2.png"
                alt="UnrealEngineLogo"
                className="hover:scale-125 transition w-full h-full"
              />
              <div className="ease-in-out duration-300 -bottom-40 absolute bg-background opacity-80 px-12 py-8">
                <p className="text-primary font-bold text-[23px]">
                  BEGIN
                </p>
                <p className="text-white text-[20px]">
                  Try Clothes Like You've Never Done Before
                </p>
              </div>
            </div>
          </Slider>
        </div>
      </div>
    </div>
  );
}
