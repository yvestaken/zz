import { createContext } from "react";

export const ThemeContext = createContext({
  darkToggle: false,
  setDarkToggle: () => {},
});