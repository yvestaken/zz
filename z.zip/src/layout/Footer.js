// helpers
import scrollTo from "../helpers/ScrollTo";

export default function Footer() {
  const GoTopIcon = () => {
    return (
      <svg
        width="45"
        height="27"
        viewBox="0 0 45 27"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M22.5 0L44.5836 27H0.416351L22.5 0Z"
          className="fill-[#1EE1B3] hover:fill-[#00C2FF]"
        />
      </svg>
    );
  };

  return (
    <div
      className="w-full bg-background px-6 md:px-16 lg:px-40 pt-24 pb-7 flex flex-col items-center"
      id="contact"
    >
      <div
        className="hover:scale-125 transition cursor-pointer"
        onClick={() => {
          scrollTo("header");
        }}
      >
        <GoTopIcon />
      </div>
      <h1 className="font-bold text-[64px] text-white mb-8">BEGIN</h1>
      <div className="flex flex-row space-x-8 mb-24">
        <div className="cursor-pointer w-12 h-12 bg-[url(/public/static/img/social/facebook.svg)] bg-no-repeat hover:bg-[url(/public/static/img/social/facebook-variant.svg)]"></div>
        <div className="cursor-pointer w-12 h-12 bg-[url(/public/static/img/social/twitter.svg)] bg-no-repeat hover:bg-[url(/public/static/img/social/twitter-variant.svg)]"></div>
        <div className="cursor-pointer w-12 h-12 bg-[url(/public/static/img/social/instagram.svg)] bg-no-repeat hover:bg-[url(/public/static/img/social/instagram-variant.svg)]"></div>
      </div>
      <div className="w-full flex flex-row items-center justify-center md:justify-between">
        <div className="flex flex-row space-x-5 items-center">
          <div className="w-4 h-4 rounded-full border border-white text-[10px] text-white leading-3 text-center">
            C
          </div>
          <p className="text-[10px] leading-3 text-white">
            All Rights Reserved
          </p>
        </div>
        <div className="text-[10px] leading-3 text-white space-x-9 flex-row hidden md:flex">
          <p className="hover:text-[11px]">Terms and Conditions</p>
          <p className="hover:text-[11px]">Privacy Policy</p>
        </div>
      </div>
    </div>
  );
}
