import React, { useContext } from "react";

// context
import { ThemeContext } from "../hooks/context/ThemeContext";

// component
import SlideBar from "../components/slidebar";

// helpers
import scrollTo from "../helpers/ScrollTo";

export default function Header() {
  const { darkToggle, setDarkToggle } = useContext(ThemeContext);

  return (
    <div
      className="transition duration-1000 z-50 w-full absolute top-0 h-[70px] opacity-95 px-6 md:px-16 lg:px-40 xl:px-52 flex flex-row justify-between items-center bg-background dark:bg-white"
      id="header"
    >
      <div className="flex lg:!hidden">
        <SlideBar pageWrapId={"page-wrap"} outerContainerId={"App"} />
      </div>
      <div id="page-wrap">
        <div className="text-white dark:text-black hidden lg:flex flex-row gap-10 xl:gap-20 items-center ">
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("about")}
          >
            About
          </div>
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("features")}
          >
            Features
          </div>
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("why-begin")}
          >
            Why Begin
          </div>
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("specs")}
          >
            Specs
          </div>
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("store")}
          >
            Cross-Store&nbsp;Shopping
          </div>
          <div
            className="transition duration-500 cursor-pointer hover:text-primary"
            onClick={() => scrollTo("contact")}
          >
            Contact
          </div>
        </div>
      </div>
      <div className="flex flex-row items-center">
        <label
          htmlFor="dark-toggle"
          className="inline-flex relative items-center cursor-pointer mr-10"
        >
          <input
            type="checkbox"
            value=""
            id="dark-toggle"
            className="sr-only peer"
            onClick={() => {
              setDarkToggle(!darkToggle);
            }}
          />
          <div className="w-11 h-6 bg-[#CDCDCD] peer-focus:outline-none peer-focus:ring-0 rounded-full peer dark:bg-[#CDCDCD] peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-[#232427] after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-[#CDCDCD]"></div>
          {!darkToggle && (
            <div className="absolute left-1.5">
              <svg
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.91375 5.83333C2.91375 7.44392 4.22392 8.75408 5.8345 8.75408C7.44508 8.75408 8.75525 7.44392 8.75525 5.83333C8.75525 4.22275 7.44508 2.91258 5.8345 2.91258C4.22392 2.91258 2.91375 4.22275 2.91375 5.83333ZM5.25 9.91667H6.41667V11.6667H5.25V9.91667ZM5.25 0H6.41667V1.75H5.25V0ZM0 5.25H1.75V6.41667H0V5.25ZM9.91667 5.25H11.6667V6.41667H9.91667V5.25ZM2.12158 10.3705L1.29675 9.54567L2.534 8.30842L3.35883 9.13325L2.12158 10.3705ZM8.30783 2.534L9.54567 1.29617L10.3705 2.121L9.13267 3.35883L8.30783 2.534ZM2.534 3.35942L1.29675 2.12158L2.12217 1.29675L3.35883 2.53458L2.534 3.35942ZM10.3705 9.54567L9.54567 10.3705L8.30783 9.13267L9.13267 8.30783L10.3705 9.54567Z"
                  fill="#1EE1B3"
                />
              </svg>
            </div>
          )}

          {darkToggle && (
            <div className="absolute left-7">
              <svg
                width="10"
                height="10"
                viewBox="0 0 10 10"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M5.04866 4.9515C4.41341 4.31598 3.98078 3.50641 3.80546 2.6251C3.63014 1.74378 3.71998 0.83027 4.06364 0C3.0838 0.192895 2.18378 0.673688 1.47866 1.38089C-0.492888 3.3525 -0.492888 6.54949 1.47866 8.5211C3.45072 10.4932 6.6471 10.4927 8.61916 8.5211C9.32615 7.81603 9.8069 6.91619 10 5.93655C9.16974 6.28015 8.25628 6.36996 7.37501 6.19463C6.49373 6.01931 5.68419 5.58671 5.04866 4.9515V4.9515Z"
                  fill="#1EE1B3"
                />
              </svg>
            </div>
          )}
        </label>
        <div className="transition duration-500 mr-7 cursor-pointer text-white hover:!text-primary dark:text-black">
          LogIn
        </div>
        <div className="transition duration-500 bg-primary px-6 py-3.5 rounded-md hover:bg-[#1EB2E1] hover:text-white">
          <strong>SIGN UP</strong>
        </div>
      </div>
    </div>
  );
}
