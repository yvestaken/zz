import PrimaryButton from "./PrimaryButton";

export { PrimaryButton };
