import React from "react";

export default function PrimaryButton(props) {
  return (
    <div className="transition duration-500 ease-in-out cursor-pointer rounded-sm flex items-center justify-center uppercase w-44 h-12 text-[14px] font-bold text-center bg-white hover:!bg-primary dark:bg-background text-background dark:text-white">
      {props.children}
    </div>
  );
}
