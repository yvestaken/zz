import React, { useState, useRef } from "react";

const AccordionDownIcon = () => {
  return (
    <svg
      width="21"
      height="14"
      viewBox="0 0 21 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M20.9973 11.6552C20.998 12.0855 20.8762 12.5025 20.6531 12.8338C20.5274 13.0203 20.3731 13.1744 20.199 13.2874C20.0248 13.4004 19.8343 13.47 19.6383 13.4922C19.4422 13.5145 19.2446 13.4889 19.0566 13.417C18.8686 13.3451 18.694 13.2283 18.5427 13.0732L10.5205 4.82303L2.48335 12.7786C2.33026 12.9315 2.1541 13.0458 1.96501 13.1147C1.77592 13.1836 1.57763 13.2059 1.38152 13.1802C1.18541 13.1546 0.99536 13.0814 0.822289 12.9651C0.649218 12.8488 0.496539 12.6915 0.373029 12.5023C0.236776 12.3118 0.134003 12.0886 0.0711587 11.8469C0.00831448 11.6052 -0.0132433 11.3501 0.00783732 11.0976C0.0289179 10.8452 0.0921822 10.6008 0.19366 10.3798C0.295138 10.1589 0.432638 9.96612 0.597531 9.81365L9.57762 0.918931C9.84542 0.648072 10.1813 0.5 10.528 0.5C10.8747 0.5 11.2106 0.648072 11.4784 0.918931L20.4585 10.1267C20.6396 10.3115 20.7828 10.5461 20.8764 10.8117C20.97 11.0773 21.0114 11.3663 20.9973 11.6552Z"
        fill="#1EE1B3"
      />
    </svg>
  );
};

const AccordionUpIcon = () => {
  return (
    <svg
      width="21"
      height="14"
      viewBox="0 0 21 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0.00270835 2.3448C0.00202554 1.91451 0.123817 1.49752 0.346945 1.1662C0.472589 0.979727 0.6269 0.825585 0.801035 0.712602C0.975168 0.599619 1.16571 0.530015 1.36174 0.507777C1.55777 0.485538 1.75544 0.511103 1.94343 0.583006C2.13141 0.654908 2.30603 0.771735 2.45726 0.926798L10.4795 9.17697L18.5167 1.22145C18.6697 1.06848 18.8459 0.954243 19.035 0.88531C19.2241 0.816378 19.4224 0.794106 19.6185 0.819776C19.8146 0.845446 20.0046 0.91855 20.1777 1.03489C20.3508 1.15123 20.5035 1.3085 20.627 1.49768C20.7632 1.68822 20.866 1.91135 20.9288 2.15308C20.9917 2.39481 21.0132 2.64991 20.9922 2.90237C20.9711 3.15484 20.9078 3.39922 20.8063 3.62017C20.7049 3.84112 20.5674 4.03388 20.4025 4.18635L11.4224 13.0811C11.1546 13.3519 10.8187 13.5 10.472 13.5C10.1253 13.5 9.7894 13.3519 9.5216 13.0811L0.541515 3.87329C0.36039 3.68855 0.217211 3.45387 0.123596 3.1883C0.0299796 2.92273 -0.0114366 2.63375 0.00270835 2.3448Z"
        fill="#1EE1B3"
      />
    </svg>
  );
};

const Accordion = (props) => {
  const { title } = props;
  const [isOpened, setOpened] = useState(false);
  const [height, setHeight] = useState("0px");
  const contentElement = useRef(null);

  const HandleOpening = () => {
    setOpened(!isOpened);
    setHeight(!isOpened ? `${contentElement.current.scrollHeight}px` : "0px");
  };
  return (
    <div onClick={HandleOpening} className="w-full border-t-2 border-[#292936]">
      <div className="py-5 flex justify-between items-center bg-background dark:bg-white">
        <h4 className=" text-[#565660] text-[36px] font-semibold text-primary">{title}</h4>
        {isOpened ? <AccordionDownIcon /> : <AccordionUpIcon />}
      </div>
      <div
        ref={contentElement}
        style={{ height: height }}
        className="overflow-hidden transition-all duration-200 bg-background dark:bg-white"
      >
        <div className="w-full flex flex-col">
          <div className="flex flex-row items-center justify-between">
            <div className="flex flex-row space-x-8">
              <div className="w-16 h-16">
                <svg
                  width="64"
                  height="63"
                  viewBox="0 0 64 63"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M50.7691 5.69238H13.2306C9.34336 5.69238 6.19214 8.84361 6.19214 12.7308V50.2693C6.19214 54.1565 9.34336 57.3078 13.2306 57.3078H50.7691C54.6563 57.3078 57.8075 54.1565 57.8075 50.2693V12.7308C57.8075 8.84361 54.6563 5.69238 50.7691 5.69238Z"
                    stroke="#D1D1D1"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M46.0771 15.0767H17.9233C16.6276 15.0767 15.5771 16.1271 15.5771 17.4228V45.5767C15.5771 46.8724 16.6276 47.9228 17.9233 47.9228H46.0771C47.3729 47.9228 48.4233 46.8724 48.4233 45.5767V17.4228C48.4233 16.1271 47.3729 15.0767 46.0771 15.0767Z"
                    stroke="#D1D1D1"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M32 5.69231V1M43.7308 5.69231V1M20.2692 5.69231V1M32 62V57.3077M43.7308 62V57.3077M20.2692 62V57.3077M57.8077 31.5H62.5M57.8077 43.2308H62.5M57.8077 19.7692H62.5M1.5 31.5H6.19231M1.5 43.2308H6.19231M1.5 19.7692H6.19231"
                    stroke="#D1D1D1"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <h2 className="text-[36px] font-semibold text-white">MIRROR</h2>
            </div>
            <div className="w-60 md:w-[400px] lg:w-[685px] py-5 text-[18px] text-[#A4A4A4] border-b-2 border-[#262626]">
            Carbon steel frame paired with mineral bronze powder coating that fits any wall or room.
            </div>
          </div>
          <div className="flex flex-row items-center justify-between">
            <div className="w-16 h-16"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Accordion;