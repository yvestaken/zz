import React from "react";
import { slide as Menu } from "react-burger-menu";

export default function SlideBar(props) {
  return (
    // Pass on our props
    <Menu {...props}>
      <a className="menu-item" href="#about">
        About
      </a>

      <a className="menu-item" href="#features">
        Features
      </a>

      <a className="menu-item" href="#why-begin">
        Why Begin
      </a>

      <a className="menu-item" href="#specs">
        Specs
      </a>

      <a className="menu-item" href="#store">
        Shopping
      </a>

      <a className="menu-item" href="#contact">
        Contact
      </a>
    </Menu>
  );
};
