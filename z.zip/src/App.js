import React, { useState, useMemo } from "react";
import { useRoutes } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";

// context
import { ThemeContext } from "./hooks/context/ThemeContext";

import BaseLayout from "./layout";
import Welcome from "./pages/welcome";

const Routes = () => {
  return useRoutes([
    {
      element: <BaseLayout />,
      children: [
        {
          path: "/",
          element: <Welcome />,
        },
      ],
    },
  ]);
};

function App() {
  const [darkToggle, setDarkToggle] = useState(false);

  if (
    localStorage.theme === "dark" ||
    (!("theme" in localStorage) &&
      window.matchMedia("(prefers-color-scheme: dark)").matches)
  ) {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }

  // Whenever the user explicitly chooses light mode
  if (!darkToggle) {
    localStorage.theme = "light";
  }
  // Whenever the user explicitly chooses dark mode
  if (darkToggle) {
    localStorage.theme = "dark";
  }

  const themeValue = useMemo(
    () => ({ darkToggle, setDarkToggle }),
    [darkToggle]
  );

  return (
    <Router>
      <ThemeContext.Provider value={themeValue}>
        <Routes />
      </ThemeContext.Provider>
    </Router>
  );
}

export default App;
